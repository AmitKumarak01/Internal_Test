#include<stdio.h>
#include "solution_8_file.h"
#include "lib_dynamic.so"
#include "library_MulDiv.a"

int main()
{
	int choice,a,b;

	int result;

	return 0;
}
