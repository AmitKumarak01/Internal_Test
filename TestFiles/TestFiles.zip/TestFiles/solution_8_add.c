#include<stdio.h>
#include "solution_8_file.h"

int Addition(int a,int b)
{
	return a+b;
}
