int Addition(int a,int b);
int Subtraction(int a,int b);
int Multiply(int a,int b);
int Division(int a,int b);
